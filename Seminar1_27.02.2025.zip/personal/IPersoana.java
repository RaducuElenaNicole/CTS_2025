package ro.cts.model.personal;

public interface IPersoana {
  String getNume();
  int getVarsta();
}
